This file needs the diabetes.csv database in the same directory in order to work!!

The way this program works is that it will create plots based on the clustering from the code. The program takes a while to create all the
images and then the video. It creates 100 frames for the video. The process of the image creation is stored in tempImages. IT WILL TAKE A WHILE! 
To reduce the number of plots for testing or grading, change the "frames" variable in line 166 to a smaller number. The program can also run until
convergance, but that would take longer. Its turned off for testing and grading purposes